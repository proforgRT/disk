# QXlsx for Qt 5.11

This package contains a static QXlsx library rebuilt on Debian 10 with Qt 5.11.3.

Files:
- `libQXlsx.a` - static library.
- `libQXlsx/` - public QXlsx headers.
- `QXlsx.pri`, `QXlsx.pro` - original qmake project files.
- `build_qt_version.txt` - exact build environment.

Use this library instead of the older prebuilt `libQXlsx.a` when building ACMS with Qt 5.11. It removes the need for the temporary `QString::split(QChar, QFlags<...>)` compatibility shim because the library now references the Qt 5.11 ABI:

```text
QString::split(QChar, QString::SplitBehavior, Qt::CaseSensitivity) const
```

Build note: current QXlsx sources use Qt private zip headers, so `qtbase5-private-dev` is required in the Debian 10 build image.
