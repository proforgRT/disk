QT += core gui
CONFIG += console c++11
CONFIG -= app_bundle

INCLUDEPATH += ../libQXlsx
LIBS += ../libQXlsx.a

SOURCES += main.cpp
