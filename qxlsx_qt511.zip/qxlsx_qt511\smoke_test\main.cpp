#include <QCoreApplication>
#include "xlsxdocument.h"

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);

    QXlsx::Document xlsx;
    xlsx.write(1, 1, "qt511-ok");
    return xlsx.saveAs("out.xlsx") ? 0 : 1;
}
