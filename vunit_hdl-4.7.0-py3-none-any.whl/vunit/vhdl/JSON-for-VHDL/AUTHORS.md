# List of Authors and Contributors (in alphabetical order)

Contributor       | Contact E-Mail
------------------|------------------------------------------------------------
Lehmann, Patrick  | Patrick.Lehmann@tu-dresden.de; Paebbels@gmail.com
