# JSONTestSuite

**This directory contains the JSON testcase files from [JSONTestSuite](https://github.com/nst/JSONTestSuite).**

**Author:**       Nicolas Seriot  
**Copyright:**    Copyright (c) 2016 Nicolas Seriot  
**License:**      MIT License  
**Repository:**   https://github.com/nst/JSONTestSuite
